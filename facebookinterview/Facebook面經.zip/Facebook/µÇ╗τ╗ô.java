Remove Duplicates from Sorted Array: 1,2
Parentheses: 1,Valid Parentheses  
             2,Remove Invalid Parentheses  
             3,balancedParentheses
two three sum: 1,2sum
               2,3sum
Best Time to Buy and Sell Stock: 1,2
                                 3,Find max drop value in a list
                                 4,what if there are some transition fee for each transition?(follow 2)
move zero
subsets: 1,2
Permutations: 1,2(iteration不需要会)
decode ways
add binary
valid Palindrome
Divide Two Integers
sort color
Intersection of Two Arrays 1,2
    
    
stack,queue,hashset/map stringbuilder List space O(n)
recursion space O(n), stack overflow
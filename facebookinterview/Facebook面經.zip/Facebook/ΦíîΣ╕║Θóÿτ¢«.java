introduce yourself, what's your favourite project, and the challenging part?
Which team would you like to work with?
What are the technologies you are most interested in?
Why Facebook?
简历，对FB的了解，对FB哪个Product比较感兴趣，说了15分钟
    
    
